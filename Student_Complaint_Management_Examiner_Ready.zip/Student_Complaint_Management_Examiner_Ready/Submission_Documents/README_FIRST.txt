STUDENT COMPLAINT MANAGEMENT SYSTEM — EXAM SUBMISSION BUNDLE

Included:
1. Source_Code\StudentCompliantManagement.zip — ASP.NET Core MVC source project.
2. Database_Backup\StudentComplaintDB.bak — SQL Server database backup supplied for this project.
3. RUN_PROJECT.bat — extracts the source on first run and starts the website at http://localhost:5018.
4. RUN_GUIDE.txt — examiner setup, database restore, run instructions and troubleshooting.
5. Submission_Documents — report draft, presentation and dashboard reference image.
6. Project_Workspace — VS Code workspace file.

START HERE:
Read RUN_GUIDE.txt first. Restore the database backup in SSMS, then double-click RUN_PROJECT.bat.

The report and presentation are drafts. Fill in student name, roll number, college, guide and academic year, and verify screenshots/details before final submission.

The dashboard PNG is a reference/overview image; it should not be represented as a verified screenshot of the running application unless you confirm that it matches the actual output.

localhost is a local development URL, not a permanent public website link. The examiner's computer needs .NET 10 SDK and SQL Server LocalDB, and the backup must be restored before database features work.
