@echo off
setlocal
 title Student Complaint Management System
cd /d "%~dp0"

 echo ================================================
 echo   Student Complaint Management System
 echo ================================================
 echo.

 where dotnet >nul 2>nul
 if errorlevel 1 (
   echo .NET SDK is not installed or not in PATH.
   echo Install the .NET 10 SDK, then run this file again.
   pause
   exit /b 1
 )

 if not exist "Project_Source\StudentCompliantManagement.csproj" (
   echo Extracting project source code...
   if not exist "Source_Code\StudentCompliantManagement.zip" (
     echo Source ZIP was not found. Keep this RUN_PROJECT.bat beside the Source_Code folder.
     pause
     exit /b 1
   )
   powershell -NoProfile -Command "Expand-Archive -LiteralPath 'Source_Code\StudentCompliantManagement.zip' -DestinationPath 'Project_Source' -Force"
   if errorlevel 1 (
     echo Could not extract the project source.
     pause
     exit /b 1
   )
 )

 set "PROJECT="
 for /r "Project_Source" %%F in (*.csproj) do if not defined PROJECT set "PROJECT=%%F"
 if not defined PROJECT (
   echo Could not find a .csproj file in Project_Source.
   pause
   exit /b 1
 )

 echo.
 echo Starting the website at http://localhost:5018
 echo Keep this window open while using the website.
 echo.
 start "" cmd /c "timeout /t 5 /nobreak ^>nul ^& start http://localhost:5018"
 dotnet run --project "%PROJECT%" --urls "http://localhost:5018"
 echo.
 echo Website stopped. Press any key to close.
 pause >nul
